<?php
define('PLX_CONFIG_PATH', 'data/configuration/');
?>