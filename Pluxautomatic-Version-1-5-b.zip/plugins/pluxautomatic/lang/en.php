<?php
$LANG = array(
# config.php
'INFO'	  => 'Code to place in your sidebar.php file of your template',
'LABEL_JQUERY'	  => 'Activate Select ?',
'SUBMIT'  => 'submit',
);
?>