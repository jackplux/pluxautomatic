<?php
$LANG = array(
# config.php
'INFO'	  => 'Code à placer dans votre fichier sidebar.php de votre template',
'LABEL_JQUERY'	  => 'Activer Select ?',
'SUBMIT'  => 'Valider',
);
?>