<?php if(!defined('PLX_ROOT')) exit; ?>

<h2>Aide</h2>

Le principe du plugin plux-automatic est de copier une archive dans un répertoire nommé "sites" qui se trouve à la racine de votre site (et non de votre hébergement).<br /><br />

Grâce au plugin, vous donnerez un nom à vos sites de test (toujours un seul mot, majuscules et tirets acceptés) et  pourrez les supprimer quand vous n'en aurez plus besoin. Tout se fait tout seul. ;)<br /><br />

<strong>Problème connu</strong><br /><br />

<p> Sous Firefox, le clic sur une case à cocher ouvre le site mais reste cochée. Ce bug ne se produit pas avec Chrome. </p>

<p> Je vous souhaite de trés bons tests et bon vent. :)</p>





