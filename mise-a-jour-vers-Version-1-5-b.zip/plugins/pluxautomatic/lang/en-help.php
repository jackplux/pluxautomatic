<?php if(!defined('PLX_ROOT')) exit; ?>

<H2> Help </ h2>

Traduction with Google. Sorry is non good. ;)

The plugin-automatic plux principle is to copy an archive in a directory named "sites" which is at the root of your website (not your hoster). <br /> <br />

With the plugin, you give a name to your test sites (always a single word), can remove when you no longer need and even purge the entire directory "sites" with a single click. Everything else is done alone. ;) <br /> <br />

<Strong> Known issue troubleshooting</ strong> <br /> <br />

In Firefox, click on a check box opens the site but remains checked. This bug does not occur with Chrome. <br />




<P> I wish you a very good testing and good luck. :) </ P>





